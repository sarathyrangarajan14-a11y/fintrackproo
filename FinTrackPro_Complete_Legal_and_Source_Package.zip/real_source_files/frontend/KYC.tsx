import { useState, useEffect, useRef } from "react";
import { CheckCircle2, FileText, Upload, Camera, X, Smartphone, PenTool, ShieldCheck, ArrowRight, Save, User, Building, Briefcase } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { auth } from "../../lib/firebase";
import SignatureCanvas from 'react-signature-canvas';

export default function KYC() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [kycStatus, setKycStatus] = useState<string>(() => localStorage.getItem('client_kyc_status') || 'NOT_STARTED');
  const [kycRejectionReason, setKycRejectionReason] = useState<string>('');
  const navigate = useNavigate();
  const sigCanvas = useRef<SignatureCanvas>(null);
  
  const [kycData, setKycData] = useState({
    fullName: "",
    dob: "",
    gender: "",
    fatherName: "",
    mobile: "",
    email: "",
    maritalStatus: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    pan: "",
    aadhaarNumber: "",
    bankAccountName: "",
    bankName: "",
    bankAccountNumber: "",
    bankIfsc: "",
    bankAccountType: "Savings",
    occupation: "",
    annualIncome: "",
    sourceOfIncome: "",
    investmentExperience: "",
    isFatca: false,
    isPep: false,
    nomineeName: "",
    nomineeRelation: "",
    panDocumentUrl: "",
    aadhaarDocumentUrl: "",
    bankProofUrl: "",
    photoUrl: "",
    signatureUrl: ""
  });

  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const user = auth.currentUser;
        if (!user) return;
        
        // Auto-fill email and mobile from user profile
        setKycData(prev => ({
          ...prev,
          email: user.email || "",
          mobile: user.phoneNumber || "",
          fullName: user.displayName || ""
        }));

        const token = await user.getIdToken();
        const res = await fetch("/api/client/profile", {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          const status = data.kycStatus || 'NOT_STARTED';
          setKycStatus(status);
          localStorage.setItem('client_kyc_status', status);
          setKycRejectionReason(data.kycRejectionReason || '');
          if (data.kycStatus && data.kycStatus !== 'NOT_STARTED') {
             // Load existing data
             setKycData(prev => ({
                ...prev,
                ...data
             }));
          }
        }
      } catch (err) {
        console.error("Failed to fetch profile", err);
      }
    };
    
    auth.onAuthStateChanged((user) => {
      if (user) fetchProfile();
    });
  }, []);

  const handleNext = () => setStep(s => Math.min(s + 1, 6));
  const handleBack = () => setStep(s => Math.max(s - 1, 1));

  // Simulated File Uploads (In prod: Upload to Firebase Storage and get URL)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            const MAX_WIDTH = 800;
            const MAX_HEIGHT = 800;
            let width = img.width;
            let height = img.height;

            if (width > height) {
              if (width > MAX_WIDTH) {
                height = Math.round((height * MAX_WIDTH) / width);
                width = MAX_WIDTH;
              }
            } else {
              if (height > MAX_HEIGHT) {
                width = Math.round((width * MAX_HEIGHT) / height);
                height = MAX_HEIGHT;
              }
            }
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
            setKycData(prev => ({ ...prev, [field]: dataUrl }));
          };
          img.src = event.target?.result as string;
        };
        reader.readAsDataURL(file);
      } else {
        // Fallback for PDF or other types. Just limit size manually?
        if (file.size > 500 * 1024) {
           alert("File is too large! Please upload a file smaller than 500KB.");
           return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
          setKycData(prev => ({ ...prev, [field]: reader.result as string }));
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleSaveDraft = async () => {
    setLoading(true);
    try {
      if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
        kycData.signatureUrl = sigCanvas.current.toDataURL();
      }
      const user = auth.currentUser;
      const token = await user?.getIdToken();
      
      const res = await fetch("/api/client/kyc", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({...kycData, isDraft: true})
      });
      
      if (res.ok) {
        setKycStatus('PENDING');
        setNotification({ message: "Draft saved successfully", type: 'success' });
      } else {
        setNotification({ message: "Failed to save draft", type: 'error' });
      }
    } catch (error) {
      console.error(error);
      setNotification({ message: "Error saving draft", type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
        kycData.signatureUrl = sigCanvas.current.toDataURL();
      }

      const user = auth.currentUser;
      const token = await user?.getIdToken();
      
      const res = await fetch("/api/client/kyc", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(kycData)
      });
      
      if (res.ok) {
        setKycStatus('SUBMITTED');
        setNotification({ message: "KYC submitted successfully", type: 'success' });
        setTimeout(() => navigate("/dashboard"), 3000);
      } else {
        setNotification({ message: "Failed to submit KYC", type: 'error' });
      }
    } catch (error) {
      console.error(error);
      setNotification({ message: "Error submitting KYC", type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  if (kycStatus === 'VERIFIED') {
    return (
      <div className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-md w-full bg-slate-800/80 backdrop-blur-xl border border-emerald-500/30 rounded-[32px] p-8 shadow-2xl text-center">
          <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-emerald-500/20 mb-6">
            <CheckCircle2 className="h-10 w-10 text-emerald-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">KYC VERIFIED</h2>
          <p className="text-slate-400 mb-8">
            Your KYC has been successfully verified. You can now invest in mutual fund schemes.
          </p>
          <button
            onClick={() => navigate("/explore")}
            className="w-full inline-flex justify-center py-3 px-8 border border-transparent shadow-[0_0_15px_rgba(16,185,129,0.3)] text-sm font-bold rounded-xl text-black bg-emerald-400 hover:bg-emerald-500 transition-colors"
          >
            Browse Mutual Funds
          </button>
        </div>
      </div>
    );
  }

  if (kycStatus === 'SUBMITTED') {
    return (
      <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-md mx-auto w-full bg-slate-800/80 backdrop-blur-xl border border-slate-700 rounded-[32px] p-8 shadow-2xl text-center">
          <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-blue-500/20 mb-6">
            <ShieldCheck className="h-10 w-10 text-blue-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">KYC Under Review</h2>
          <p className="text-slate-400 mb-8">
            Your KYC application has been submitted and is pending verification from your partner. We will notify you once it is approved.
          </p>
          <button
            onClick={() => navigate("/dashboard")}
            className="w-full inline-flex justify-center py-3 px-8 border border-slate-600 text-sm font-bold rounded-xl text-white bg-slate-700 hover:bg-slate-600 transition-colors"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-4xl w-full mx-auto space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white">Complete Your KYC</h2>
          <p className="mt-2 text-slate-400">
            Secure and paperless digital KYC verification
          </p>
        </div>
        
        {kycStatus === 'CORRECTION_REQUIRED' && (
          <div className="bg-amber-900/30 border border-amber-500/50 rounded-xl p-4 mb-6">
            <h3 className="font-bold text-amber-400 mb-1">Correction Required</h3>
            <p className="text-amber-200 text-sm">{kycRejectionReason}</p>
          </div>
        )}

        <div className="bg-slate-900 border border-slate-800 rounded-[32px] p-6 sm:p-8 shadow-2xl">
          {/* Progress Bar */}
          <div className="mb-10">
            <div className="flex justify-between items-center mb-2 relative">
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-700 -z-10 -translate-y-1/2"></div>
              {[1, 2, 3, 4, 5, 6].map((num) => (
                <div key={num} className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-xs ${step > num ? 'bg-emerald-500 text-black' : step === num ? 'bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400' : 'bg-slate-800 text-slate-500 border border-slate-700'}`}>
                  {step > num ? <CheckCircle2 className="w-4 h-4" /> : num}
                </div>
              ))}
            </div>
            <div className="flex justify-between text-[10px] sm:text-xs font-bold text-slate-400 px-1">
              <span className={step >= 1 ? 'text-emerald-400' : ''}>Personal</span>
              <span className={step >= 2 ? 'text-emerald-400' : ''}>PAN & Aadhaar</span>
              <span className={step >= 3 ? 'text-emerald-400' : ''}>Bank Details</span>
              <span className={step >= 4 ? 'text-emerald-400' : ''}>Investor Info</span>
              <span className={step >= 5 ? 'text-emerald-400' : ''}>Documents</span>
              <span className={step >= 6 ? 'text-emerald-400' : ''}>Review & Submit</span>
            </div>
          </div>

          <form onSubmit={step === 6 ? handleSubmit : (e) => { e.preventDefault(); handleNext(); }}>
            
            {/* Step 1: Personal Info */}
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-2"><User className="inline-block w-5 h-5 mr-2" /> Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Full Name</label>
                    <input type="text" required value={kycData.fullName} onChange={e => setKycData({...kycData, fullName: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Date of Birth</label>
                    <input type="date" required value={kycData.dob} onChange={e => setKycData({...kycData, dob: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 [color-scheme:dark]" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Gender</label>
                    <select required value={kycData.gender} onChange={e => setKycData({...kycData, gender: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Father's / Mother's Name</label>
                    <input type="text" required value={kycData.fatherName} onChange={e => setKycData({...kycData, fatherName: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Mobile Number</label>
                    <input type="tel" required value={kycData.mobile} onChange={e => setKycData({...kycData, mobile: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
                    <input type="email" required value={kycData.email} onChange={e => setKycData({...kycData, email: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Marital Status</label>
                    <select required value={kycData.maritalStatus} onChange={e => setKycData({...kycData, maritalStatus: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Single">Single</option>
                      <option value="Married">Married</option>
                    </select>
                  </div>
                </div>
                
                <h4 className="font-bold text-white mt-6 mb-2">Address Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-1">Full Address</label>
                    <textarea required rows={2} value={kycData.address} onChange={e => setKycData({...kycData, address: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">City</label>
                    <input type="text" required value={kycData.city} onChange={e => setKycData({...kycData, city: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">State</label>
                    <input type="text" required value={kycData.state} onChange={e => setKycData({...kycData, state: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">PIN Code</label>
                    <input type="text" required pattern="[0-9]{6}" value={kycData.pincode} onChange={e => setKycData({...kycData, pincode: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: PAN & Aadhaar */}
            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-2"><FileText className="inline-block w-5 h-5 mr-2" /> PAN & Aadhaar</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">PAN Number</label>
                      <input type="text" required pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" placeholder="ABCDE1234F" value={kycData.pan} onChange={e => setKycData({...kycData, pan: e.target.value.toUpperCase()})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white uppercase focus:outline-none focus:border-emerald-500" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Upload PAN Card</label>
                      <div className="border-2 border-dashed border-slate-600 rounded-xl p-4 text-center hover:bg-slate-800 transition-colors cursor-pointer relative">
                        <input type="file" accept="image/*,.pdf" onChange={e => handleFileUpload(e, 'panDocumentUrl')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" required={!kycData.panDocumentUrl} />
                        {kycData.panDocumentUrl ? (
                          <div className="text-emerald-400 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 mr-2" /> PAN Uploaded</div>
                        ) : (
                          <div className="text-slate-400"><Upload className="w-6 h-6 mx-auto mb-2 opacity-50" /> Click to upload PAN</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">Aadhaar Number</label>
                      <input type="text" required pattern="[0-9]{12}" placeholder="1234 5678 9012" value={kycData.aadhaarNumber} onChange={e => setKycData({...kycData, aadhaarNumber: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Upload Aadhaar (Front & Back)</label>
                      <div className="border-2 border-dashed border-slate-600 rounded-xl p-4 text-center hover:bg-slate-800 transition-colors cursor-pointer relative">
                        <input type="file" accept="image/*,.pdf" onChange={e => handleFileUpload(e, 'aadhaarDocumentUrl')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" required={!kycData.aadhaarDocumentUrl} />
                        {kycData.aadhaarDocumentUrl ? (
                          <div className="text-emerald-400 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 mr-2" /> Aadhaar Uploaded</div>
                        ) : (
                          <div className="text-slate-400"><Upload className="w-6 h-6 mx-auto mb-2 opacity-50" /> Click to upload Aadhaar</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Bank Details */}
            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-2"><Building className="inline-block w-5 h-5 mr-2" /> Bank Account Details</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Account Holder Name</label>
                    <input type="text" required value={kycData.bankAccountName} onChange={e => setKycData({...kycData, bankAccountName: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Bank Name</label>
                    <input type="text" required value={kycData.bankName} onChange={e => setKycData({...kycData, bankName: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Account Number</label>
                    <input type="password" required value={kycData.bankAccountNumber} onChange={e => setKycData({...kycData, bankAccountNumber: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">IFSC Code</label>
                    <input type="text" required pattern="^[A-Z]{4}0[A-Z0-9]{6}$" placeholder="SBIN0001234" value={kycData.bankIfsc} onChange={e => setKycData({...kycData, bankIfsc: e.target.value.toUpperCase()})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white uppercase focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Account Type</label>
                    <select required value={kycData.bankAccountType} onChange={e => setKycData({...kycData, bankAccountType: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="Savings">Savings</option>
                      <option value="Current">Current</option>
                      <option value="NRE">NRE</option>
                      <option value="NRO">NRO</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Upload Bank Proof (Cancelled Cheque / Passbook)</label>
                    <div className="border-2 border-dashed border-slate-600 rounded-xl p-4 text-center hover:bg-slate-800 transition-colors cursor-pointer relative">
                      <input type="file" accept="image/*,.pdf" onChange={e => handleFileUpload(e, 'bankProofUrl')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" required={!kycData.bankProofUrl} />
                      {kycData.bankProofUrl ? (
                        <div className="text-emerald-400 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 mr-2" /> Bank Proof Uploaded</div>
                      ) : (
                        <div className="text-slate-400"><Upload className="w-6 h-6 mx-auto mb-2 opacity-50" /> Click to upload proof</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Investor Info */}
            {step === 4 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-2"><Briefcase className="inline-block w-5 h-5 mr-2" /> Investor Profile & Nominee</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Occupation</label>
                    <select required value={kycData.occupation} onChange={e => setKycData({...kycData, occupation: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Private Sector">Private Sector Service</option>
                      <option value="Public Sector">Public Sector Service</option>
                      <option value="Government">Government Service</option>
                      <option value="Business">Business</option>
                      <option value="Professional">Professional</option>
                      <option value="Agriculturist">Agriculturist</option>
                      <option value="Retired">Retired</option>
                      <option value="Student">Student</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Annual Income</label>
                    <select required value={kycData.annualIncome} onChange={e => setKycData({...kycData, annualIncome: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Below 1 Lakh">Below 1 Lakh</option>
                      <option value="1-5 Lakhs">1-5 Lakhs</option>
                      <option value="5-10 Lakhs">5-10 Lakhs</option>
                      <option value="10-25 Lakhs">10-25 Lakhs</option>
                      <option value=">25 Lakhs">&gt;25 Lakhs</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Source of Wealth</label>
                    <select required value={kycData.sourceOfIncome} onChange={e => setKycData({...kycData, sourceOfIncome: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Salary">Salary</option>
                      <option value="Business">Business Income</option>
                      <option value="Gift">Gift</option>
                      <option value="Ancestral">Ancestral Property</option>
                      <option value="Others">Others</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Investment Experience</label>
                    <select required value={kycData.investmentExperience} onChange={e => setKycData({...kycData, investmentExperience: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500">
                      <option value="">Select</option>
                      <option value="Novice">Novice (0-1 yr)</option>
                      <option value="Intermediate">Intermediate (1-3 yrs)</option>
                      <option value="Expert">Expert (3+ yrs)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  <label className="flex items-start gap-3 p-4 bg-slate-800 rounded-xl border border-slate-700 cursor-pointer hover:border-emerald-500">
                    <input type="checkbox" checked={kycData.isFatca} onChange={e => setKycData({...kycData, isFatca: e.target.checked})} className="mt-1 w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500" />
                    <span className="text-sm text-slate-300">I am a tax resident of a country other than India (FATCA/CRS declaration)</span>
                  </label>
                  <label className="flex items-start gap-3 p-4 bg-slate-800 rounded-xl border border-slate-700 cursor-pointer hover:border-emerald-500">
                    <input type="checkbox" checked={kycData.isPep} onChange={e => setKycData({...kycData, isPep: e.target.checked})} className="mt-1 w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500" />
                    <span className="text-sm text-slate-300">I am a Politically Exposed Person (PEP) or related to one</span>
                  </label>
                </div>

                <h4 className="font-bold text-white mt-6 mb-2">Nominee Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Nominee Name</label>
                    <input type="text" required value={kycData.nomineeName} onChange={e => setKycData({...kycData, nomineeName: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Relationship</label>
                    <input type="text" required value={kycData.nomineeRelation} onChange={e => setKycData({...kycData, nomineeRelation: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500" />
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Final Documents & IPV */}
            {step === 5 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
                <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-2"><Camera className="inline-block w-5 h-5 mr-2" /> Live Photo & Signature</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Recent Photograph</label>
                    <div className="border-2 border-dashed border-slate-600 rounded-xl p-8 text-center hover:bg-slate-800 transition-colors cursor-pointer relative">
                      <input type="file" accept="image/*" onChange={e => handleFileUpload(e, 'photoUrl')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" required={!kycData.photoUrl} />
                      {kycData.photoUrl ? (
                        <div>
                          <img src={kycData.photoUrl} alt="Preview" className="w-24 h-24 object-cover rounded-full mx-auto mb-2 border-2 border-emerald-500" />
                          <div className="text-emerald-400 flex items-center justify-center text-sm"><CheckCircle2 className="w-4 h-4 mr-1" /> Photo Uploaded</div>
                        </div>
                      ) : (
                        <div className="text-slate-400">
                          <Camera className="w-8 h-8 mx-auto mb-3 opacity-50" />
                          <p>Click to upload or take photo</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-end mb-2">
                      <label className="block text-sm font-medium text-slate-300">Digital Signature</label>
                      <button type="button" onClick={() => sigCanvas.current?.clear()} className="text-xs text-emerald-400 hover:underline">Clear Pad</button>
                    </div>
                    <div className="bg-white rounded-xl overflow-hidden border-2 border-slate-600 touch-none">
                      <SignatureCanvas 
                        ref={sigCanvas}
                        penColor="black"
                        canvasProps={{className: 'w-full h-40 cursor-crosshair'}} 
                      />
                    </div>
                    <p className="text-xs text-slate-500 mt-2 flex items-center"><PenTool className="w-3 h-3 mr-1" /> Sign clearly inside the box.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Step 6: Review */}
            {step === 6 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-6 text-center">
                  <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
                  <h3 className="text-xl font-bold text-emerald-400 mb-2">Ready to Submit</h3>
                  <p className="text-slate-300 text-sm max-w-md mx-auto">
                    Please ensure all information provided is accurate. Submitting false information may lead to rejection of your application.
                  </p>
                </div>
                
                <div className="bg-slate-800 rounded-xl p-6 space-y-3 text-sm">
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Name</span>
                    <span className="text-white font-medium">{kycData.fullName}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">PAN</span>
                    <span className="text-white font-medium uppercase">{kycData.pan}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Bank Details</span>
                    <span className="text-white font-medium">{kycData.bankAccountNumber} ({kycData.bankIfsc})</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-slate-400">Documents Attached</span>
                    <span className="text-emerald-400 font-medium">Verified ✓</span>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 flex items-center justify-between pt-6 border-t border-slate-800">
              <button
                type="button"
                onClick={handleBack}
                disabled={step === 1 || loading}
                className={`inline-flex justify-center py-3 px-6 border border-slate-700 shadow-sm text-sm font-bold rounded-xl transition-colors ${step === 1 ? 'opacity-0 pointer-events-none' : 'text-slate-300 bg-slate-800 hover:bg-slate-700'}`}
              >
                Back
              </button>
              
              <div className="flex gap-3">
                {step < 6 && (
                  <button
                    type="button"
                    onClick={handleSaveDraft}
                    className="inline-flex items-center justify-center py-3 px-6 text-sm font-bold rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
                  >
                    <Save className="w-4 h-4 mr-2" /> Save Draft
                  </button>
                )}
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center justify-center py-3 px-8 border border-transparent shadow-[0_0_15px_rgba(16,185,129,0.2)] text-sm font-bold rounded-xl text-black bg-emerald-400 hover:bg-emerald-500 disabled:opacity-50 transition-colors"
                >
                  {loading ? "Processing..." : step === 6 ? "Confirm & Submit" : (
                    <>Next <ArrowRight className="w-4 h-4 ml-2" /></>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      
      {/* Toast Notification */}
      {notification && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl border ${notification.type === 'success' ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-400' : 'bg-red-950/90 border-red-500/50 text-red-400'} backdrop-blur-xl animate-in slide-in-from-bottom-5 fade-in duration-300`}>
          <div className="font-bold text-sm">
            {notification.message}
          </div>
          <button onClick={() => setNotification(null)} className="opacity-50 hover:opacity-100">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
