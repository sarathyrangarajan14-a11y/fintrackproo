import { adminDb } from './src/lib/firebase-admin.ts';
async function run() {
  try {
    const doc = await adminDb.collection('kyc_applications').limit(1).get();
    console.log("Admin SDK Success:", doc.empty ? "Empty" : "Found docs");
  } catch (e) {
    console.error("Admin SDK Error:", e);
  }
}
run();
