import { db } from './src/db';
import { users, partners } from './src/db/schema';
import { eq } from 'drizzle-orm';

async function main() {
  const allPartners = await db.query.partners.findMany({
    with: { user: true }
  });
  console.log("All Partners:", JSON.stringify(allPartners, null, 2));
}
main();
