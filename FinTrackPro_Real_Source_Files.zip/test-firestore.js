import { initializeApp, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';
const firebaseConfig = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const app = initializeApp({ projectId: firebaseConfig.projectId });
const db = getFirestore(app);
db.collection('test').limit(1).get().then(() => console.log('success')).catch(e => console.error(e.message));
