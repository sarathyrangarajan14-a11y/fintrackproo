fetch("http://localhost:3000/api/partner/sips/pending", {
  headers: { Authorization: `Bearer MOCK_TOKEN` }
}).then(res => res.json()).then(console.log).catch(console.error);
