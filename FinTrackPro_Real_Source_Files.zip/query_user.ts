import { db } from './src/db';
import { users, partners, clients } from './src/db/schema';
import { eq } from 'drizzle-orm';

async function main() {
  const user = await db.query.users.findFirst({
    where: eq(users.email, "sarathyrangarajan14@gmail.com")
  });
  console.log("User:", user);
  
  if (user) {
    const partner = await db.query.partners.findFirst({
      where: eq(partners.userId, user.id)
    });
    console.log("Partner:", partner);
    
    if (partner) {
      const partnerClients = await db.query.clients.findMany({
        where: eq(clients.partnerId, partner.id),
        with: { sips: true }
      });
      console.log("Partner Clients Sips:", JSON.stringify(partnerClients, null, 2));
    }
  }
}
main();
