import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../../lib/firebase';
import { User, Mail, Phone, ChevronRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import ClientLayout from '../../components/layout/ClientLayout';

export default function ProfileSetup() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phoneNumber: ''
  });
  
  const [lockedFields, setLockedFields] = useState({
    email: false,
    phoneNumber: false
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          navigate('/login');
          return;
        }

        const token = await user.getIdToken();
        const res = await fetch("/api/client/profile", {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        let existingProfile: any = null;
        if (res.ok) {
          existingProfile = await res.json();
          // If profile is fully complete, go to dashboard
          if (existingProfile.fullName && existingProfile.email && existingProfile.phoneNumber && 
              !existingProfile.email.includes('@fintrackpro.client') && !existingProfile.email.includes('@mobile.client')) {
             navigate('/dashboard');
             return;
          }
        }

        // Determine locked fields based on auth provider
        const providers = user.providerData.map(p => p.providerId);
        const isGoogle = providers.includes('google.com');
        const isPhone = providers.includes('phone');

        let defaultEmail = existingProfile?.email || user.email || '';
        let defaultPhone = existingProfile?.phoneNumber || user.phoneNumber || '';
        
        // Clean fallbacks
        if (defaultEmail.includes('@mobile.client') || defaultEmail.includes('@fintrackpro.client')) {
          defaultEmail = '';
        }

        const locks = { email: false, phoneNumber: false };

        if (isGoogle && user.email) {
          locks.email = true;
          defaultEmail = user.email;
        }
        if (isPhone && user.phoneNumber) {
          locks.phoneNumber = true;
          defaultPhone = user.phoneNumber;
        }

        setFormData({
          fullName: existingProfile?.fullName || '',
          email: defaultEmail,
          phoneNumber: defaultPhone
        });
        setLockedFields(locks);
        
      } catch (err) {
        console.error("Error fetching profile", err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProfile();
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("Not authenticated");
      
      const token = await user.getIdToken();
      const res = await fetch("/api/client/profile/setup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });
      
      if (!res.ok) {
        throw new Error("Failed to save profile");
      }
      
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred while saving your profile.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <ClientLayout>
        <div className="min-h-screen pt-24 px-4 sm:px-6 lg:px-8 pb-12 bg-[#020617] text-white flex justify-center items-center">
           Loading Profile...
        </div>
      </ClientLayout>
    );
  }

  return (
    <ClientLayout>
      <div className="min-h-screen pt-24 px-4 sm:px-6 lg:px-8 pb-12 bg-[#020617] text-white">
        <div className="max-w-xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-4">Complete Your Profile</h1>
            <p className="text-slate-400">Please provide your details to continue setting up your FinTrackPro account.</p>
          </div>
          
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8">
            {error && (
              <div className="mb-6 bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-xs font-semibold flex items-start gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">{error}</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Full Name (As per PAN)</label>
                <div className="relative">
                  <User className="absolute left-4 top-3.5 h-5 w-5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={e => setFormData({...formData, fullName: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                    placeholder="Enter your full name"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-3.5 h-5 w-5 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    disabled={lockedFields.email}
                    className={`w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-slate-600 focus:outline-none transition-colors ${lockedFields.email ? 'opacity-60 cursor-not-allowed' : 'focus:border-blue-500 focus:ring-1 focus:ring-blue-500'}`}
                    placeholder="Enter your email"
                  />
                  {lockedFields.email && (
                    <span className="absolute right-4 top-3.5 text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded font-bold uppercase">Locked</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-3.5 h-5 w-5 text-slate-400" />
                  <input
                    type="tel"
                    required
                    value={formData.phoneNumber}
                    onChange={e => setFormData({...formData, phoneNumber: e.target.value})}
                    disabled={lockedFields.phoneNumber}
                    className={`w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-slate-600 focus:outline-none transition-colors ${lockedFields.phoneNumber ? 'opacity-60 cursor-not-allowed' : 'focus:border-blue-500 focus:ring-1 focus:ring-blue-500'}`}
                    placeholder="e.g. +91 9876543210"
                  />
                  {lockedFields.phoneNumber && (
                    <span className="absolute right-4 top-3.5 text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-bold uppercase">Locked</span>
                  )}
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold transition-all disabled:opacity-50"
                >
                  {submitting ? 'Saving Profile...' : 'Save & Continue'}
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </ClientLayout>
  );
}
