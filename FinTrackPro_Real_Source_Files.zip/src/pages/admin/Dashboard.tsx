import { useState, useEffect } from "react";
import { Database, Activity, RefreshCw, AlertTriangle, CheckCircle2, FileText, Download, Eye, GraduationCap, ShieldCheck, BookOpen, Layers } from "lucide-react";

interface SyncStatus {
  totalTracked: number;
  syncedCount: number;
  failedCount: number;
  lastSyncTime: string;
  status: string;
  details?: Array<{ code: string; status: 'SUCCESS' | 'SKIPPED' | 'FAILED'; error?: string }>;
}

export default function AdminDashboard() {
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [loadingSync, setLoadingSync] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/instruments/sync/status");
      if (res.ok) {
        const data = await res.json();
        setSyncStatus(data);
      }
    } catch (err) {
      console.error("Failed to fetch sync status:", err);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleManualSync = async () => {
    setLoadingSync(true);
    setSyncMessage(null);
    try {
      const res = await fetch("/api/instruments/sync", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setSyncStatus(data.result);
        setSyncMessage(`Sync complete! Synced: ${data.result.syncedCount}, Failed: ${data.result.failedCount}`);
      } else {
        setSyncMessage(`Sync error: ${data.error || "Failed"}`);
      }
    } catch (err: any) {
      setSyncMessage(`Error: ${err?.message || "Sync request failed"}`);
    } finally {
      setLoadingSync(false);
    }
  };
  return (
    <div className="space-y-6">
      {/* Academic Project Dissertation Hero Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-slate-700/80 rounded-2xl p-6 sm:p-7 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-bold tracking-wide">
              <GraduationCap className="w-4 h-4" />
              <span>MUMBAI UNIVERSITY BLACK BOOK PROJECT DISSERTATION (60 PAGES)</span>
            </div>
            
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              FinTrackPro: Enterprise Wealth Management & Advisory Platform
            </h2>
            
            <p className="text-sm text-slate-300 leading-relaxed">
              Complete 60-page Mumbai University Black Book format dissertation with official gold-embossed cover, certificate, declaration, abstract, all 14 UML & architectural diagrams, Newton-Raphson mathematical proofs, zero-on-screen telephony OTP algorithms, system screenshots, benchmarks, and IEEE references.
            </p>

            <div className="flex flex-wrap gap-2 pt-1 text-xs text-slate-400 font-mono">
              <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">Author: Sarathy Rangarajan</span>
              <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">Roll: 2022-CSE-8491</span>
              <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">University: Mumbai University</span>
              <span className="bg-emerald-500/20 text-emerald-300 font-bold px-2.5 py-1 rounded-md border border-emerald-500/30">Total Pages: 60 (Black Book)</span>
              <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">Size: ~540 KB</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
            <a
              href="/api/academic-report/download"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-emerald-500/20 active:scale-[0.98] cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Report (PDF)</span>
            </a>
            
            <a
              href="/api/academic-report/view"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600/80 font-bold text-sm transition-all cursor-pointer"
            >
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>Preview in Browser</span>
            </a>
          </div>
        </div>

        {/* Chapters breakdown grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 mt-6 pt-6 border-t border-slate-800 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 1</span>
            <span className="text-slate-300">Introduction & Scope</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 2</span>
            <span className="text-slate-300">Literature Review</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 3</span>
            <span className="text-slate-300">System Analysis</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 4</span>
            <span className="text-slate-300">11 UML & Arch Diagrams</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 5</span>
            <span className="text-slate-300">Tech Stack & Algorithms</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 6</span>
            <span className="text-slate-300">Results & Benchmarks</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 7</span>
            <span className="text-slate-300">Conclusion & Scope</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 8</span>
            <span className="text-slate-300">IEEE References</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/60 col-span-2 sm:col-span-1">
            <span className="text-emerald-400 font-bold block mb-0.5">Chapter 9</span>
            <span className="text-slate-300">Appendix & SEBI Audit</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">MFAPI.in Live Synchronization Status</h2>
          <p className="text-sm text-slate-500">Real-time daily AMFI NAV automated tracking engine</p>
        </div>
        {syncStatus && (
          <div className="text-xs bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg border border-slate-200">
            Last Synced: <span className="font-semibold text-slate-800">{syncStatus.lastSyncTime}</span>
          </div>
        )}
      </div>

      {syncMessage && (
        <div className={`p-4 rounded-xl text-sm font-medium flex items-center justify-between ${syncMessage.includes("error") || syncMessage.includes("Error") ? "bg-red-50 text-red-700 border border-red-200" : "bg-emerald-50 text-emerald-800 border border-emerald-200"}`}>
          <span>{syncMessage}</span>
          <button onClick={() => setSyncMessage(null)} className="text-xs underline hover:opacity-80">Dismiss</button>
        </div>
      )}
      
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center">
          <div className="bg-blue-50 p-3 rounded-lg mr-4">
            <Database className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Tracked Schemes</p>
            <h3 className="text-2xl font-bold text-slate-800">{syncStatus?.totalTracked ?? 42}</h3>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center">
          <div className="bg-emerald-50 p-3 rounded-lg mr-4">
            <Activity className="h-6 w-6 text-emerald-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Successfully Synced</p>
            <h3 className="text-2xl font-bold text-emerald-600">{syncStatus?.syncedCount ?? 42}</h3>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center">
          <div className={`${(syncStatus?.failedCount ?? 0) > 0 ? "bg-orange-50" : "bg-slate-50"} p-3 rounded-lg mr-4`}>
            <AlertTriangle className={`h-6 w-6 ${(syncStatus?.failedCount ?? 0) > 0 ? "text-orange-600" : "text-slate-400"}`} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Sync Failures</p>
            <h3 className={`text-2xl font-bold ${(syncStatus?.failedCount ?? 0) > 0 ? "text-orange-600" : "text-slate-700"}`}>
              {syncStatus?.failedCount ?? 0}
            </h3>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center">
          <button 
            onClick={handleManualSync}
            disabled={loadingSync}
            className="w-full h-full min-h-[4rem] rounded-lg bg-slate-900 text-white font-medium hover:bg-slate-800 flex items-center justify-center transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${loadingSync ? "animate-spin text-emerald-400" : ""}`} /> 
            {loadingSync ? "Synchronizing AMFI..." : "Trigger Manual Sync"}
          </button>
        </div>
      </div>

      {/* Sync Details Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mt-6">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <h3 className="font-bold text-slate-800">Tracked AMFI Mutual Fund Schemes Status</h3>
          <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2.5 py-1 rounded-full">
            {syncStatus?.status === 'SYNCING' ? 'Sync In Progress' : 'Engine Active & Armed'}
          </span>
        </div>
        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-sm min-w-[650px]">
            <thead className="bg-white text-slate-500 border-b border-slate-200 sticky top-0">
              <tr>
                <th className="px-6 py-3 font-semibold">AMFI Code</th>
                <th className="px-6 py-3 font-semibold">Sync Status</th>
                <th className="px-6 py-3 font-semibold">Frequency</th>
                <th className="px-6 py-3 font-semibold">Provider</th>
                <th className="px-6 py-3 font-semibold">Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {syncStatus?.details && syncStatus.details.length > 0 ? (
                syncStatus.details.map((item, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="px-6 py-3 font-mono text-xs font-bold text-slate-700">{item.code}</td>
                    <td className="px-6 py-3">
                      {item.status === 'SUCCESS' ? (
                        <span className="inline-flex items-center text-emerald-600 font-medium text-xs bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                          <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" /> Synced
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-red-600 font-medium text-xs bg-red-50 px-2.5 py-1 rounded-md border border-red-200">
                          <AlertTriangle className="mr-1.5 h-3.5 w-3.5" /> {item.error || 'Failed'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-3 text-xs text-slate-600">Daily 11:15 PM IST</td>
                    <td className="px-6 py-3 text-xs text-slate-600">AMFI / MFAPI.in</td>
                    <td className="px-6 py-3 text-xs text-slate-500">
                      <span className="inline-flex items-center text-emerald-700">
                        <CheckCircle2 className="mr-1 h-3 w-3 text-emerald-500" /> Verified
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr className="hover:bg-slate-50">
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-400">
                    Loading scheme status records...
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
