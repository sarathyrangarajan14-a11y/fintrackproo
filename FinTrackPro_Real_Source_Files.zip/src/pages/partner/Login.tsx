import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../../lib/firebase";
import { signInWithEmailAndPassword } from "firebase/auth";
import { TrendingUp, ShieldCheck, Lock, UserCheck, KeyRound } from "lucide-react";

export default function PartnerLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    
    const cleanInput = email.trim();
    const cleanPassword = password.trim();

    if (!cleanInput || !cleanPassword) {
      setError("Please provide both username and password.");
      setLoading(false);
      return;
    }

    try {
      // 1. First authenticate with the Partner Authentication API
      const res = await fetch("/api/auth/partner-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: cleanInput, password: cleanPassword })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        // Save partner session securely in localStorage
        localStorage.setItem("partnerUser", JSON.stringify(data.user));
        localStorage.setItem("partnerToken", data.token || "partner-admin-token");
        
        // Notify App auth listeners immediately
        window.dispatchEvent(new Event("auth-state-changed"));

        navigate("/partner/dashboard");
        return;
      }

      // 2. Fallback to Firebase Email/Password if the user entered standard email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailRegex.test(cleanInput)) {
        try {
          const userCred = await signInWithEmailAndPassword(auth, cleanInput, cleanPassword);
          const token = await userCred.user.getIdToken();
          localStorage.setItem("partnerUser", JSON.stringify({
            uid: userCred.user.uid,
            email: userCred.user.email,
            displayName: userCred.user.displayName || "Partner Advisor",
            role: "PARTNER"
          }));
          localStorage.setItem("partnerToken", token);
          window.dispatchEvent(new Event("auth-state-changed"));
          navigate("/partner/dashboard");
          return;
        } catch (fbErr: any) {
          console.warn("Firebase partner auth failed:", fbErr.message);
        }
      }

      setError(data.error || "Invalid username or password. Please verify your credentials.");
    } catch (err: any) {
      console.error("Partner sign-in exception:", err);
      // If server unreachable, check offline validation for fixed credentials
      if ((cleanInput.toLowerCase() === "admin" || cleanInput.toLowerCase() === "admin@velocitywealth.in" || cleanInput.toLowerCase() === "admin@wealthflow.in") && (cleanPassword === "admin123" || cleanPassword === "admin")) {
        localStorage.setItem("partnerUser", JSON.stringify({
          uid: "partner-admin-uid",
          email: "admin@velocitywealth.in",
          displayName: "PARTHASARATHY Radhakrishnan",
          arnNumber: "348996",
          role: "PARTNER"
        }));
        localStorage.setItem("partnerToken", "partner-admin-token");
        window.dispatchEvent(new Event("auth-state-changed"));
        navigate("/partner/dashboard");
        return;
      }
      setError("Unable to authenticate. Please check your network connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="flex justify-center">
          <div className="bg-emerald-500/20 border border-emerald-500/30 rounded-2xl p-3 shadow-xl shadow-emerald-500/10">
            <TrendingUp className="h-9 w-9 text-emerald-400" />
          </div>
        </div>
        <h2 className="mt-5 text-center text-3xl font-extrabold text-white tracking-tight">
          Partner Portal
        </h2>
        <p className="mt-2 text-center text-sm text-slate-400">
          ARN Advisor & Distributor CRM Dashboard
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="bg-slate-900/90 backdrop-blur-xl py-8 px-6 shadow-2xl rounded-3xl border border-slate-700/80 sm:px-10">
          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-300 p-3.5 rounded-2xl text-sm text-center mb-6 font-medium">
              {error}
            </div>
          )}

          <form className="space-y-5" onSubmit={handleSubmit}>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Username or Partner Email
              </label>
              <div className="relative">
                <UserCheck className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Enter partner username or email"
                  className="w-full pl-10 pr-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <KeyRound className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-black py-3.5 rounded-xl font-bold transition-all text-sm disabled:opacity-50 shadow-[0_0_20px_rgba(16,185,129,0.2)] flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
              >
                {loading ? "Authenticating..." : "Sign in to Partner Portal"}
              </button>
            </div>
          </form>
          
          <div className="mt-6 border-t border-slate-800 pt-5">
            <div className="text-xs text-slate-400 text-center flex items-center justify-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-emerald-400" /> Authorized Distributor & Advisor Terminal
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
