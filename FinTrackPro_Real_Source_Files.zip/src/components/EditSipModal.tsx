import React, { useState } from 'react';
import { X, Edit3, Calendar, IndianRupee, AlertCircle } from 'lucide-react';

interface EditSipModalProps {
  isOpen: boolean;
  onClose: () => void;
  sip: any;
  onConfirm: (updatedData: { amount: number; sipDate: number }) => void;
}

export default function EditSipModal({ isOpen, onClose, sip, onConfirm }: EditSipModalProps) {
  if (!isOpen || !sip) return null;

  const [amount, setAmount] = useState(sip.amount?.toString() || "5000");
  const [sipDate, setSipDate] = useState(sip.sipDate?.toString() || "5");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < 500) {
      setError("Minimum monthly SIP amount is ₹500");
      return;
    }
    setError("");
    onConfirm({
      amount: numAmount,
      sipDate: parseInt(sipDate)
    });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0f172a] border border-white/10 rounded-[32px] w-full max-w-md overflow-hidden relative shadow-2xl animate-in zoom-in-95 duration-200">
        <button 
          onClick={onClose} 
          className="absolute right-6 top-6 text-slate-400 hover:text-white p-2 rounded-full hover:bg-white/5 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 md:p-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Edit3 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Modify SIP Mandate</h3>
              <p className="text-slate-400 text-xs mt-0.5">Update your monthly recurring investment terms</p>
            </div>
          </div>

          <div className="bg-white/[0.03] rounded-2xl p-4 mb-6 border border-white/5 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Scheme Code</span>
              <span className="text-white font-bold">{sip.schemeCode}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Current Amount</span>
              <span className="text-emerald-400 font-bold">₹{sip.amount} / month</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Current Debit Day</span>
              <span className="text-white font-bold">{sip.sipDate}th of every month</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-emerald-400" /> New Monthly Amount (₹)
              </label>
              <input
                type="number"
                min="500"
                step="100"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[#1e293b]/70 border border-white/10 rounded-xl px-4 py-3 text-white text-base font-bold focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                placeholder="e.g. 5000"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" /> New Monthly Debit Day
              </label>
              <select
                value={sipDate}
                onChange={(e) => setSipDate(e.target.value)}
                className="w-full bg-[#1e293b] border border-white/10 rounded-xl px-4 py-3 text-white font-medium focus:outline-none focus:border-emerald-500"
              >
                {[...Array(28)].map((_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {i + 1}th of every month
                  </option>
                ))}
              </select>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/20 p-2.5 rounded-xl">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex gap-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-3.5 rounded-xl font-bold transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-black py-3.5 rounded-xl font-bold transition-colors text-sm shadow-[0_0_15px_rgba(16,185,129,0.3)]"
              >
                Proceed to OTP
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
