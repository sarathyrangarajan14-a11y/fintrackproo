import { db } from './src/db';
import { users, partners, clients, sips } from './src/db/schema';
import { eq } from 'drizzle-orm';

async function main() {
  const partnerClients = await db.query.clients.findMany({
    where: eq(clients.partnerId, 1),
    with: { user: true, sips: true, transactions: true }
  });
  console.log(JSON.stringify(partnerClients, null, 2));
}
main();
