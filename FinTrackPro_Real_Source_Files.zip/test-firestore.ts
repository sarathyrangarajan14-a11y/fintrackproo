import { setDocumentREST } from './src/lib/firestore-rest.ts';
import { adminAuth } from './src/lib/firebase-admin.ts'; // wait, no admin token

async function run() {
    console.log("Testing...");
}
run();
